package com.his.system.fee;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicalFeeRepository extends JpaRepository<MedicalFee, Long> {
}
