package com.his.system.staff;

public enum StaffRole {
    ADMIN, DOCTOR, NURSE
}