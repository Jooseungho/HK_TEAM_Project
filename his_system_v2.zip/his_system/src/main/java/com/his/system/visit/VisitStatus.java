package com.his.system.visit;

public enum VisitStatus {
    WAITING,
    CALLED,
    IN_TREATMENT,
    DONE,
    CANCELLED,
    PAID
}
