package com.his.system.prescription;

public enum PrescriptionStatus {
    ORDERED,
    SENT,
    DONE,
    CANCELLED
}
