package com.his.system.nurse;

public enum NurseTaskStatus {
    PENDING,
    DONE
}
