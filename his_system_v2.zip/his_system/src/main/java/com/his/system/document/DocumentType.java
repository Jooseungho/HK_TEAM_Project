package com.his.system.document;

public enum DocumentType {
    CERTIFICATION,
    OPINION,
    PRESCRIPTION,
    OTHERS
}
