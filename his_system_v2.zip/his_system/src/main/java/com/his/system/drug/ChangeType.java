package com.his.system.drug;

public enum ChangeType {
    IN,
    OUT
}
