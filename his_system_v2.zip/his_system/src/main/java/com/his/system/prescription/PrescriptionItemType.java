package com.his.system.prescription;

public enum PrescriptionItemType {
    DRUG,
    INJECTION,
    TEST,
    PROCEDURE,
    TREATMENT   // ← 추가
}
