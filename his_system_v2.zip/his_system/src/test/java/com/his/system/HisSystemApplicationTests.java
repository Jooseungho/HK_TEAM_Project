package com.his.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HisSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
